export function buildStartPayload(user) {
  const partnerId = user.partner_id || user.sh_ref_tail || process.env.MY_PARTNER_ID || 'p_qdr';
  const webId = user.web_id || user.id || '';
  let emailEncoded = '';
  if (user.email) {
    emailEncoded = Buffer.from(user.email).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
  }
  return `${partnerId}__${webId}__${emailEncoded || 'noemail'}`;
}

export function parseStartPayload(payload) {
  if (!payload) return null;
  const parts = payload.split('__');
  if (parts.length < 3) {
    return { partnerId: parts[0] || null };
  }
  const [partnerId, webId, emailEncoded] = parts;
  let email = null;
  if (emailEncoded && emailEncoded !== 'noemail') {
    try {
      email = Buffer.from(emailEncoded.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8');
    } catch (e) {}
  }
  return {
    partnerId: partnerId || null,
    webId: webId || null,
    email
  };
}